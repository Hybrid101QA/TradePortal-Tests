package common;

public class Constants {
    public static String COMMAND_HISTORY_FILENAME = ".command_history_jspy.txt";
}
